package poof;

import java.io.IOException;

public class IllegalRemovalExceptionC extends Exception {
	
}